angular.module('app.settings', ['ngMaterial', "ng", "ngAnimate", "ngAria"])
  .controller('SettingsCtrl', function ($scope) {

  });